# SENTINEL evaluation � summary statistics

| Metric | Value |
|---|---|
| frames | 49 |
| total_detections | 454 |
| priority_detections | 430 |
| review_detections | 24 |
| deferral_rate | 0.0529 |
| defer_threshold | 0.35 |
| mean_confidence_priority | 0.5656 |
| mean_confidence_review | 0.3896 |
| mean_uncertainty_priority | 0.1141 |
| mean_uncertainty_review | 0.4547 |
| highest_priority_score | 0.9 |
| mean_priority_score | 0.3219 |
| nai_breach_detections | 253 |
| class_count_person | 285 |
| class_count_car | 162 |
| class_count_truck | 2 |
| class_count_boat | 2 |
| class_count_bus | 1 |
| class_count_motorcycle | 1 |
| class_count_bicycle | 1 |

*Label-free evaluation: distributions and deferral behaviour only. No ground-truth accuracy is claimed by this table.*
